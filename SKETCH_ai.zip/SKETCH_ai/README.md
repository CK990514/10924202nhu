# Sketcher 

## Project Description 

* Train on google colab using sketcher.ipynb and convert the model to web format then save to the model 
* Make inference on the browser using TensorFlow.js 


